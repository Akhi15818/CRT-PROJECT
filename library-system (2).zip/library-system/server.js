const express = require("express");
const db = require("./db");

const app = express();

app.use(express.json());
app.use(express.static("public"));


// ADD BOOK
app.post("/addBook", (req, res) => {

  const book = req.body.book;
  const author = req.body.author;

  const sql = "INSERT INTO books (book_name, author) VALUES (?, ?)";

  db.query(sql, [book, author], (err, result) => {

    if (err) {
      console.log(err);
      res.send("Error adding book");
    } else {
      res.send("Book Added Successfully");
    }

  });

});


// SHOW BOOKS
app.get("/books", (req, res) => {

  db.query("SELECT * FROM books", (err, result) => {

    if (err) {
      console.log(err);
    } else {
      res.json(result);
    }

  });

});


// BORROW BOOK
app.post("/borrow/:name", (req, res) => {

  const name = req.params.name;

  const sql = "DELETE FROM books WHERE book_name=?";

  db.query(sql, [name], (err, result) => {

    if (err) {
      console.log(err);
      res.send("Error borrowing book");
    } else {
      res.send("Book Borrowed Successfully");
    }

  });

});


// RETURN BOOK
app.post("/return", (req, res) => {

  const book = req.body.book;
  const author = req.body.author;

  const sql = "INSERT INTO books (book_name, author) VALUES (?, ?)";

  db.query(sql, [book, author], (err, result) => {

    if (err) {
      console.log(err);
      res.send("Error returning book");
    } else {
      res.send("Book Returned Successfully");
    }

  });

});
// SIGNUP
app.post("/signup", (req, res) => {
    const { username, password } = req.body;
    const sql = "INSERT INTO users (username, password) VALUES (?, ?)";
    db.query(sql, [username, password], (err, result) => {
        if(err){
            console.log(err);
            res.send("Error signing up (maybe username exists)");
        } else {
            res.send("Signup Successful");
            location.reload();
        }
    });
});

// LOGIN
app.post("/login", (req, res) => {
    const { username, password } = req.body;
    const sql = "SELECT * FROM users WHERE username=? AND password=?";
    db.query(sql, [username, password], (err, result) => {
        if(err){
            console.log(err);
            res.send("Error logging in");
        } else if(result.length > 0){
            res.send("Login Successful");
        } else {
            res.send("Invalid Username or Password");
        }
    });
});


app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});