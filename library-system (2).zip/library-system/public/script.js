function addBook() {

let book = prompt("Enter Book Name");
let author = prompt("Enter Author Name");

if(book === "" || author === "" || book === null || author === null){
alert("Please enter book and author");
return;
}

fetch("/addBook",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
book:book,
author:author
})
})
.then(res=>res.text())
.then(data=>{
alert(data);
});

}

function showBooks(){

fetch("/books")
.then(res=>res.json())
.then(data=>{

let output = "";

data.forEach(function(b){

output += `
<div class="book">
<h3>${b.book_name}</h3>
<p>Author : ${b.author}</p>
</div>
`;

});

document.getElementById("books").innerHTML = output;

});

}


function borrowBook(){

let name = prompt("Enter Book Name to Borrow");

if(name === "" || name === null){
alert("Enter book name");
return;
}

fetch("/borrow/"+encodeURIComponent(name),{
method:"POST"
})
.then(res=>res.text())
.then(data=>{
alert(data);
});

}


function returnBook(){

let book = prompt("Enter Book Name");
let author = prompt("Enter Author Name");

if(book === "" || author === "" || book === null || author === null){
alert("Enter book and author");
return;
}

fetch("/return",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
book:book,
author:author
})
})
.then(res=>res.text())
.then(data=>{
alert(data);
});

}

